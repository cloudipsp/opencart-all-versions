<?php
// Text

$_['text_title'] = 'Fondy VISA/MasterCard';
$_['error_merchant'] = 'An error has occurred during payment. Merchant data is incorrect.';
$_['error_signature'] = 'An error has occurred during payment. Signature is not valid.';
$_['error_transaction'] = 'Transaction has been declined.';
$_['error_payment'] = '&nbspTransaction has been declined: ';
$_['error_code'] = 'Error code: ';
$_['order_desq'] = 'Order pay №';
